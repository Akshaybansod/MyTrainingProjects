package com.cg.bams.client;

import java.util.Scanner;

import com.cg.bams.dto.Customer;
import com.cg.bams.exception.BankAccountException;
import com.cg.bams.service.BankAccServiceImpl;

public class Main {
	static BankAccServiceImpl service = new BankAccServiceImpl();
  
	static Scanner sc = new Scanner(System.in);

	static String nameCust;
	static String mobileNoCust;
	static int ageCust;
	static double amtCust;
	static Customer customer;
	public static void main(String args[]) throws BankAccountException{
		

		int ch = 0;
		do{
			System.out.println("1.Add New Customer");
			System.out.println("2.Deposit Fund");
			System.out.println("3.Withdraw Fund");
			System.out.println("4.Fund transfer");
			System.out.println("5.Check balance");
			System.out.println("6.Exit");
			System.out.println("Please enter your choice : ");
			ch = sc.nextInt();

			switch(ch){
			case 1 : addCustomer();break;
			case 2 : deposit(); break;					
			case 3 : withdraw(); break;				
			case 4 : fundTransfer();break;
			case 5 : checkBalance(); break;
			case 6 : exit();break;
			default : System.out.println("Invalid input!!!!!");
			}

		}while(true);

	}
	private static void exit() {
		
		System.exit(0);

	}
	private static int checkBalance() throws BankAccountException {

		System.out.println("Enter the moible number");
		mobileNoCust = sc.next();
		if(!service.validateAccount(mobileNoCust)){
			System.out.println("Mobile Number not found!");
			return 0;
		}


		System.out.println("Current Amount is Rs."+service.checkBalance(mobileNoCust));
		return 0;

	}
	private static int fundTransfer() throws BankAccountException {
		String mobileNoReciever;
		System.out.println("Enter your mobile number : ");
		mobileNoCust = sc.next();

		System.out.println("Enter the amount you want to transfer : ");
		amtCust = sc.nextDouble();

		System.out.println("Enter receivers mobile number : ");
		mobileNoReciever = sc.next();
		if(mobileNoCust.equals(mobileNoReciever)){								
			System.out.println("Both numbers are same!");
			return 0;
		}
		if(service.validateMoileNo(mobileNoCust) && service.validateMoileNo(mobileNoReciever) && service.validateAmount(amtCust)){
			if(service.validateAccount(mobileNoReciever) && service.validateAccount(mobileNoCust))
				service.fundTransfer(mobileNoCust, mobileNoReciever, amtCust);
		}

		return 0;


	}
	private static int withdraw() throws BankAccountException {
		System.out.println("Enter your mobile number : ");
		mobileNoCust = sc.next();

		System.out.println("Enter the amount you want to withdraw : ");
		amtCust = sc.nextDouble();
		if(service.validateMoileNo(mobileNoCust) && service.validateAmount(amtCust)){
			if(service.validateAccount(mobileNoCust))
				service.withdraw(mobileNoCust, amtCust);
		}
		
		return 0;

	}
	private static int deposit() throws BankAccountException {
		System.out.println("Enter your mobile number : ");
		mobileNoCust = sc.next();

		System.out.println("Enter the amount you want to deposit");
		amtCust = sc.nextDouble();
		if(service.validateMoileNo(mobileNoCust)&& service.validateAmount(amtCust)){
			if(service.validateAccount(mobileNoCust))
				service.deposit(mobileNoCust, amtCust);
		}
		
		return 0;

	}
	private static int addCustomer() throws BankAccountException {
		customer = new Customer(mobileNoCust, mobileNoCust, ageCust, amtCust);						

		System.out.println("Enter customer name : ");
		nameCust = sc.next();
		if(!service.validateName(nameCust))
		{
			System.err.println("Invalid Name!");
			return 0;
		}
		System.out.println("Enter mobile no. : ");
		mobileNoCust = sc.next();
		if(!service.validateMoileNo(mobileNoCust))
		{
			System.err.println("Invalid Mobile Number");
			return 0;
		}
		else if(service.validateAccount(mobileNoCust))
		{
			System.err.println("Account already exist with this number!");
			return 0;
		}
		else
			System.out.println("Enter age : ");
		ageCust = sc.nextInt();
		if(service.validateAge(ageCust))
			System.out.println("Enter initial amount : ");
		amtCust = sc.nextDouble();
		if(service.validateAmount(amtCust))
		{
			customer.setNameCust(nameCust);
			customer.setMobileNoCust(mobileNoCust);
			customer.setAgeCust(ageCust);
			customer.setInitialBalanceCust(amtCust);

			service.createAccount(customer);

			System.out.println("Customer added");
			
		}
		else{	
			System.out.println("Invalid Amount!");
			return 0;
		}
		return 0;
	}
}

