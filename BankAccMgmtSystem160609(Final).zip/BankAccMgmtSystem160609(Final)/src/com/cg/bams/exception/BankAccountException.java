package com.cg.bams.exception;

public class BankAccountException extends Exception{
	
	public BankAccountException(String message){
		super(message);
	}

}
