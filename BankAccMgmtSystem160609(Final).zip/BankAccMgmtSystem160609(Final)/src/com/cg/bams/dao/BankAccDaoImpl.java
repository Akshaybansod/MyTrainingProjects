package com.cg.bams.dao;

import java.util.Map;

import com.cg.bams.dto.Customer;
import com.cg.bams.exception.BankAccountException;



public class BankAccDaoImpl implements IBankAccDao{
	
	
Map<String,Customer> custMap;
	
	
	public BankAccDaoImpl(){
		custMap = UtilSource.createCollection();
	}
	
	@Override
	public void createAccount(Customer customer) {
		
		custMap.put(customer.getMobileNoCust(),customer);
		
	}

	@Override
	public void deposit(String mobileNo, double amount) {
		
		Customer customer = custMap.get(mobileNo);
		if(customer == null){
			System.out.println("Mobile number not found, please enter valid mobile number!");
			
		}
		else{
			double updateAmount = customer.getInitialBalanceCust();
			updateAmount = updateAmount + amount;
			customer.setInitialBalanceCust(updateAmount);
			custMap.put(mobileNo, customer);
			System.out.println("Amount deposited");
			}
	}

	@Override
	public void withdraw(String mobileNo, double withdrawAmount) {
		
		Customer customer = custMap.get(mobileNo);
		if(customer == null){
			System.out.println("Mobile number not found, please enter valid mobile number!");
			
		}
		else{
			double amount = customer.getInitialBalanceCust();	
			
			
			
			if(amount - withdrawAmount > 100){
				amount = amount - withdrawAmount;
				
				
				customer.setInitialBalanceCust(amount);
				
				custMap.put(mobileNo, customer);
				System.out.println("Amount withdrawn");
			}
			else{
				System.out.println("Insufficient balance in Account");
				
			}
				
		}
		
	}

	@Override
	public double checkBalance(String mobileNo) {
		
		Customer custCheckBalance = custMap.get(mobileNo);
		double amount = custCheckBalance.getInitialBalanceCust();
		return amount;
		
	}

	@Override
	public void fundTransfer(String sender, String receiver, double amount) {
		
		
		
		Customer custSender =  custMap.get(sender);
		Customer custReciever = custMap.get(receiver);
		
		double recieverAmount = custReciever.getInitialBalanceCust();
		double senderAmount = custSender.getInitialBalanceCust();
		if((senderAmount - amount < 100)){
			System.err.println("Invalid Amount! \nEntered Amount exceeds the Balance amount");
			
		}
		
		else{
			
			recieverAmount = recieverAmount + amount;
			senderAmount = senderAmount - amount;
			System.out.println("Fund Transferred");
			custSender.setInitialBalanceCust(senderAmount);
			custMap.put(sender , custSender);
			custMap.put(receiver , custReciever);
		}
		
		
	}

	@Override
	public boolean validateAccount(String mobileNo) throws BankAccountException {
		
		Customer customer = custMap.get(mobileNo);
		if(customer == null)
			return false;
		return true;
	}

}
