package com.cg.bams.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bams.dto.Customer;



public class UtilSource {

	private static Map<String, Customer> customer;
	static Map<String, Customer> createCollection(){
		if(customer == null)
			customer = new HashMap<>();		
		return customer;		
	}
}
