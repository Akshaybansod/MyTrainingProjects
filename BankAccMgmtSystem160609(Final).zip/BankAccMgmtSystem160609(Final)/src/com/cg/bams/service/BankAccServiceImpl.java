package com.cg.bams.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bams.dao.BankAccDaoImpl;
import com.cg.bams.dto.Customer;
import com.cg.bams.exception.BankAccountException;

public class BankAccServiceImpl implements IBankAccService{
	
	
BankAccDaoImpl dao  = new BankAccDaoImpl();
	
	
	@Override
	public void createAccount(Customer customer) {
		
		dao.createAccount(customer);		
	}

	@Override
	public void deposit(String mobileNo, double amount) {
		
		dao.deposit(mobileNo, amount);
		
	}

	@Override
	public void withdraw(String mobileNo, double amount) {
		
		dao.withdraw(mobileNo, amount);
		
	}

	@Override
	public double checkBalance(String mobileNo) {
		
		return dao.checkBalance(mobileNo);
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		
		dao.fundTransfer(sender, reciever, amount);
		
	}

	@Override
	public boolean validateName(String name) throws BankAccountException {
		
		if(name == null){
			throw new BankAccountException("Null value found");
		}
		else{
			Pattern p = Pattern.compile("[A-Z]{1}[a-z]{2,10}");
			Matcher m = p.matcher(name); 
			if(!m.matches())
				System.out.println("Name invalid!");
			return m.matches();
		}
		
		
	}

	@Override
	public boolean validateAge(int age)  throws BankAccountException {
		try{
			
			if(age == 0)
				throw new BankAccountException("Age cannot be  null");
			else if(age >100)
				throw new BankAccountException("Age cannot be  greater than 100");
			else if(age < 0)
				throw new BankAccountException("Age cannot be a negative number");
			else if(age <17 && age > 0)
				throw new BankAccountException("Underaged Customer");
			else
				return true;
			
		
	} catch (Exception e) {
		
		e.printStackTrace();
	}
		return false;
	}

	@Override
	public boolean validateMoileNo(String mobileNo) throws BankAccountException{
		try{
			
			if(mobileNo == null)
				throw new BankAccountException("Null value found");
			Pattern p = Pattern.compile("[0-9]{10}");
			Matcher m = p.matcher(mobileNo);
			if(!m.matches())
				System.out.println("Mobile Number Invalid!");
			return m.matches();
			} catch (Exception e) {
		
				e.printStackTrace();
			
			}
			return false;
	}

	@Override
	public boolean validateAmount(double amount) throws BankAccountException {
		
		if(amount == 0){
			throw new BankAccountException("Null value found");
		}
			
		String am = String.valueOf(amount);
		
		if(am.matches("\\d{1,9}\\.\\d{0,3}")){
			
			return true;
		}
		System.out.println("Invalid Amount!");
		return (false);
		
	}

	@Override
	public boolean validateAccount(String mobileNo) throws BankAccountException {
		
		return dao.validateAccount(mobileNo);
	}

}
