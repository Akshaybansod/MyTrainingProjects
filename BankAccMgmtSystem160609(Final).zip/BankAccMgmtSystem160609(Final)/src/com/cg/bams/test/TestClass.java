package com.cg.bams.test;

import org.junit.Assert;
import org.junit.Test;

import com.cg.bams.exception.BankAccountException;
import com.cg.bams.service.BankAccServiceImpl;

public class TestClass {
	
	
	@Test(expected=BankAccountException.class)
    public void test_ValidateName_null() throws BankAccountException{
        BankAccServiceImpl service=new BankAccServiceImpl();
        service.validateName(null);
    }
    
   
    @Test
    public void test_validateName_v2() throws BankAccountException{
    
        String name="Amita";
        BankAccServiceImpl service=new BankAccServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateName_v3() throws BankAccountException{
    
        String name="amita";
        BankAccServiceImpl service=new BankAccServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    
    
    @Test
    public void test_validateMobNo_v1() throws BankAccountException{
    
        String mobNo="ABCD91828288";
        BankAccServiceImpl service=new BankAccServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateMobNo_v2() throws BankAccountException{
    
        String mobNo="9922974725";
        BankAccServiceImpl service=new BankAccServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(true,result);
    }

}
