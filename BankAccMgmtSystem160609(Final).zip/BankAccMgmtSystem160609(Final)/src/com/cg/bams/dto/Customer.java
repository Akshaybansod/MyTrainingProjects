package com.cg.bams.dto;

public class Customer {
	
	
	private String nameCust;
	private String mobileNoCust;
	private int ageCust;
	private double initialBalanceCust;
	
	
	
	public Customer(String nameCust, String mobileNoCust, int ageCust,
			double initialBalanceCust) {
		super();
		this.nameCust = nameCust;
		this.mobileNoCust = mobileNoCust;
		this.ageCust = ageCust;
		this.initialBalanceCust = initialBalanceCust;
	}

	public String getNameCust() {
		return nameCust;
	}
	
	public void setNameCust(String nameCust) {
		this.nameCust = nameCust;
	}
	
	public String getMobileNoCust() {
		return mobileNoCust;
	}
	
	public void setMobileNoCust(String mobileNoCust) {
		this.mobileNoCust = mobileNoCust;
	}
	
	public int getAgeCust() {
		return ageCust;
	}
	
	public void setAgeCust(int ageCust) {
		this.ageCust = ageCust;
	}
	
	public double getInitialBalanceCust() {
		return initialBalanceCust;
	}
	
	public void setInitialBalanceCust(double initialBalanceCust) {
		this.initialBalanceCust = initialBalanceCust;
	}
	
	
	
	
	
	@Override
	public String toString() {
		return "Customer [nameCust=" + nameCust + ", mobileNoCust="
				+ mobileNoCust + ", ageCust=" + ageCust
				+ ", initialBalanceCust=" + initialBalanceCust + "]";
	}

}
