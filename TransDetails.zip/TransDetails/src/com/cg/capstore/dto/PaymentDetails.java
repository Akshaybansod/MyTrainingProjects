package com.cg.capstore.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table
public class PaymentDetails {
	
	
	@Id
	@Column
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String paymentId;
	
	@Column
	private String userId;
	
	@Column
	private String productId;
	
	@Column
	private String paymentMode;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public PaymentDetails() {
		super();
	}

	public PaymentDetails(String userId, String productId, String paymentMode) {
		super();
		this.userId = userId;
		this.productId = productId;
		this.paymentMode = paymentMode;
	}

	@Override
	public String toString() {
		return "PaymentDetails [userId=" + userId + ", productId=" + productId
				+ ", paymentMode=" + paymentMode + "]";
	}

	



}
