package com.cg.capstore.dao;

public class CapStoreDaoImpl implements ICapstoreDao {

}
