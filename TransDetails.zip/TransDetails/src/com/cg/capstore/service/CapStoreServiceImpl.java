package com.cg.capstore.service;

public class CapStoreServiceImpl implements ICapstoreService {

}
