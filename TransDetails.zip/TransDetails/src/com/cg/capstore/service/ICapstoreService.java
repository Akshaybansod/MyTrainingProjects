package com.cg.capstore.service;

public interface ICapstoreService {

}
