package com.cg.capstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.capstore.dto.PaymentDetails;

@Controller
public class MyController {
	
	@RequestMapping("translist")
	public String showTransactionList(){
		return "transaction";
		
	}
	
	
	
	@RequestMapping("card")
	public String paymentModeCard(){
		PaymentDetails payment = new PaymentDetails();
		payment.setPaymentMode("Card Payment");
		return "detailsCard";
		
	}
	
	@RequestMapping("return")
	public String returnSuccess()
	{
		return "success";
	}
	
	
	@RequestMapping("netbank")
	public String paymentModeIB(){
		PaymentDetails payment = new PaymentDetails();
		payment.setPaymentMode("Internet Banking Payment");
		return "detailsNet";
		
	}
	
	@RequestMapping("cod")
	public String paymentModeCOD(){
		PaymentDetails payment = new PaymentDetails();
		payment.setPaymentMode("Pay On Delivery");
		return "success";
		
	}

}
