package com.cg.sts.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.sts.dto.Stocks;



@Repository
public class StockDaoImpl implements StockDao {

	@PersistenceContext
	EntityManager manager;

	@Override
	public List<Stocks> showAll() {
		String str = "SELECT stocks from Stocks stocks";
		TypedQuery<Stocks> query= manager.createQuery(str,Stocks.class);
		return query.getResultList();

	}//Implementation of sql query

	@Override
	public Stocks getOneStock(int code) {
		Stocks stock = manager.find(Stocks.class, code);
		return stock;
	}//Finding by stock code

}
