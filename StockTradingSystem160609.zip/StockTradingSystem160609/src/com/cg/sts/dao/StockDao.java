package com.cg.sts.dao;

import java.util.List;

import com.cg.sts.dto.Stocks;

public interface StockDao {

	List<Stocks> showAll();

	Stocks getOneStock(int code);

}
