package com.cg.sts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.sts.dao.StockDao;
import com.cg.sts.dto.Stocks;



@Service
@Transactional
public class StockServiceImpl implements StockService {

	@Autowired
	StockDao dao;//Initializing Dao class object

	@Override
	public List<Stocks> getAll() {

		return dao.showAll();
	}//call to method in dao

	@Override
	public Stocks getOne(int code) {
		return dao.getOneStock(code);
	}//call to method in dao



}