package com.cg.sts.service;

import java.util.List;

import com.cg.sts.dto.Stocks;

public interface StockService 
{

	public List<Stocks> getAll();
	public Stocks getOne(int code);
	
	
}
