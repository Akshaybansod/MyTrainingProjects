package com.cg.sts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.sts.dto.Stocks;
import com.cg.sts.service.StockService;



@Controller
public class StockController {

	@Autowired
	StockService service;//Initializing service class object

	@RequestMapping("getall")
	public ModelAndView getAll(){
		List<Stocks> list = service.getAll();
		return new ModelAndView("showall","list",list);

	}//This method is mapped with the first jsp page to display list

	@RequestMapping("getUpdatePage")
	public ModelAndView update(@RequestParam("stockCode") int stockId){
		Stocks stock = service.getOne(stockId);
		return new ModelAndView("order","stock",stock);
	}//call to second jsp page displaying order details

	@RequestMapping("calculate")
	public ModelAndView calculate(@RequestParam("quantity") int amount, @RequestParam("price") double price,@RequestParam("action") String action, @RequestParam("stock") String Stock, Model model){
		double newPrice = (amount * price); 
		Stocks stock = new Stocks();
		stock.setStock(Stock);
		stock.setQuote(newPrice);
		return new ModelAndView("summary","stock",stock);

	}//call to summary jsp page

}