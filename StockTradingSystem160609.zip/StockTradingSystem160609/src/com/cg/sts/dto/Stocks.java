package com.cg.sts.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "stock_master")
public class Stocks {

	@Id
	@Column (name="stock_code")
	private int stockCode;
	@Column
	private String  stock;
	@Column
	private double quote;
	public int getStockCode() {
		return stockCode;
	}
	public void setStockCode(int stockCode) {
		this.stockCode = stockCode;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	public double getQuote() {
		return quote;
	}
	public void setQuote(double quote) {
		this.quote = quote;
	}
	@Override
	public String toString() {
		return "Stocks [stockCode=" + stockCode + ", stock=" + stock
				+ ", quote=" + quote + "]";
	}
	public Stocks(int stockCode, String stock, double quote) {
		super();
		this.stockCode = stockCode;
		this.stock = stock;
		this.quote = quote;
	}
	public Stocks() {
		super();

	}



}
