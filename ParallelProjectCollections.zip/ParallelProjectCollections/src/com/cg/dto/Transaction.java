package com.cg.dto;

public class Transaction {

}
