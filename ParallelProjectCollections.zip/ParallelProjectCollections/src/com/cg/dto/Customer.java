package com.cg.dto;

public class Customer {
	private String name;
	private String mobileNo;
	private Wallet wallet;
	private Transaction transaction; 
	
}
