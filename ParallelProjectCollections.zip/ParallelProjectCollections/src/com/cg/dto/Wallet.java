package com.cg.dto;

public class Wallet {

}
