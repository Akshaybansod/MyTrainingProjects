package com.cg.dao;

import java.util.List;

import com.cg.dto.Customer;

public class EWalletDaoImpl implements IEWalletDao {

	@Override
	public Customer createAccount(String name, String mobileNo, double amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer showBalance(String mobileNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, double amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer depositAmount(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> showTransaction(String mobileNo) {
		// TODO Auto-generated method stub
		return null;
	}

}
